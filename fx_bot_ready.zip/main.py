
import telebot

API_TOKEN = '7881327270:AAEK--34AZmBzfQ83x-hRdzqZZ0eK0UQ94E'

bot = telebot.TeleBot(API_TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "✅ Benvenuto nel bot di FXGroupForexBot! Ti terrò aggiornato sui segnali.")

@bot.message_handler(func=lambda message: True)
def echo_all(message):
    bot.reply_to(message, "📈 Sto ancora imparando! A breve sarò pronto per inviarti segnali.")

bot.infinity_polling()
